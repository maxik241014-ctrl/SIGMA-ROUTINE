-- SIGMA ROUTINE: Supabase SQL setup
-- Spusť celý tento soubor v Supabase -> SQL Editor -> New query -> Run.
-- DŮLEŽITÉ: V Supabase Auth vypni potvrzování e-mailu (Confirm email),
-- protože aplikace používá interní přihlašovací alias a e-mail od uživatele nevyžaduje.

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  total_xp integer not null default 0 check (total_xp >= 0),
  total_done integer not null default 0 check (total_done >= 0),
  level integer not null default 1 check (level >= 1),
  routine_state jsonb not null default '{}'::jsonb,
  history jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Leaderboard is public" on public.profiles;
create policy "Leaderboard is public"
on public.profiles for select
using (true);

drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile"
on public.profiles for insert
with check (auth.uid() = user_id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
on public.profiles for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create or replace function public.create_sigma_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  chosen_name text;
begin
  chosen_name := lower(coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)));
  if length(chosen_name) < 3 or length(chosen_name) > 20 then
    raise exception 'Přezdívka musí mít 3 až 20 znaků.';
  end if;
  insert into public.profiles(user_id, username)
  values(new.id, chosen_name);
  return new;
end;
$$;

drop trigger if exists on_sigma_user_created on auth.users;
create trigger on_sigma_user_created
after insert on auth.users
for each row execute procedure public.create_sigma_profile();

-- Upozornění: přezdívky jsou veřejné v leaderboardu.
-- Bez e-mailu nepůjde automaticky obnovit zapomenuté heslo.
