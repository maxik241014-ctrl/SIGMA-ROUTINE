# SIGMA ROUTINE 2.0

## Co je připravené
- Animovaná úvodní obrazovka s moai a korunou.
- Krátký originální intro beat generovaný přímo v prohlížeči (po klepnutí na VSTOUPIT).
- Původní denní rutina, XP, levely a místní statistiky.
- Připravené přihlášení přezdívkou + heslem, online synchronizace a veřejný leaderboard přes Supabase.
- E-mail uživatel nevyplňuje.

## DŮLEŽITÉ: online účty ještě vyžadují jednorázové nastavení
Tato složka sama o sobě nemůže vytvořit databázi na internetu. Je potřeba založit Supabase projekt a vložit jeho veřejné URL a anon/public key do `index.html`.

1. Vytvoř projekt na https://supabase.com/ (neposílej mi heslo).
2. V Supabase otevři SQL Editor -> New query.
3. Zkopíruj celý obsah `supabase-schema.sql` a spusť ho tlačítkem Run.
4. V Supabase otevři Project Settings -> API. Zkopíruj Project URL a `anon` / `publishable` public key.
5. V `index.html` najdi:
   `const SUPABASE_URL="DOPLN_SUPABASE_URL";`
   `const SUPABASE_ANON_KEY="DOPLN_SUPABASE_ANON_KEY";`
   a nahraď pouze tyto dvě hodnoty svými údaji.
6. Nahraj `index.html` a `supabase-schema.sql` do GitHub repozitáře. `manifest.webmanifest`, `sw.js` a `icon.svg` ponech.

## Bezpečnost a omezení
- Do webu nikdy nevkládej `service_role` key ani databázové heslo. Používá se pouze veřejný anon/publishable klíč a RLS.
- Přezdívky jsou veřejné v leaderboardu. Nepoužívej celé jméno ani osobní údaje.
- Heslo musí mít alespoň 8 znaků. Nikomu ho neposílej.
- Protože e-mail není povinný, zapomenuté heslo nepůjde automaticky obnovit. Heslo si bezpečně zapamatuj.
- E-mailový alias je interní technický identifikátor; uživatel žádný e-mail nezadává. V Supabase musí být vypnuté potvrzování e-mailu.
- Online ukládání a leaderboard začnou fungovat až po nastavení Supabase. Bez něj zůstává aplikace funkční s místním ukládáním.
- Před ostrým spuštěním otestuj registraci, přihlášení a leaderboard s testovacím účtem.
